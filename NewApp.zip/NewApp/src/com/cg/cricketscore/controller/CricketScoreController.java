package com.cg.cricketscore.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.cricketscore.bean.PlayerBean;
import com.cg.cricketscore.service.CricketServiceImpl;
import com.cg.cricketscore.service.ICricketService;


@WebServlet("/CricketScoreController")
public class CricketScoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		if(request.getParameter("add").equals("View Players Details"))
		{
		ICricketService service=new CricketServiceImpl();
		ArrayList<PlayerBean> list=service.getDetails();
		if(!list.isEmpty())
		{
		/*for(PlayerBean bean:list)
			System.out.println(bean.getAge());*/
		request.setAttribute("list",list);
		
		
		getServletContext().getRequestDispatcher(
				"/views/ViewPlayers.jsp").include(request, response);
		}
		}
		else
		{
			getServletContext().getRequestDispatcher(
					"/views/NewPlayer.jsp").include(request, response);
		}
	}

}
