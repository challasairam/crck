package com.cg.cricketscore.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.cricketscore.bean.PlayerBean;
import com.cg.cricketscore.service.CricketServiceImpl;
import com.cg.cricketscore.service.ICricketService;


@WebServlet("/CricketScoreController")
public class CricketScoreController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		if(request.getParameter("add").equals("View Players Details") || request.getParameter("add").equals("Click here to view all score records"))
		{
		ICricketService service=new CricketServiceImpl();
		ArrayList<PlayerBean> list=service.getDetails();
		if(!list.isEmpty())
		{
		
		request.setAttribute("list",list);
		
		
		getServletContext().getRequestDispatcher(
				"/views/ViewPlayers.jsp").include(request, response);
		}
		else
		{
			request.setAttribute("error","No Data Found");
			getServletContext().getRequestDispatcher(
					"/views/Error.jsp").include(request, response);
		}
		}
		else if(request.getParameter("add").equals("Add New Player"))
		{
			getServletContext().getRequestDispatcher(
					"/views/NewPlayer.jsp").include(request, response);
		}
		else if(request.getParameter("add").equals("Save Player Data"))
		{
			ICricketService service=new CricketServiceImpl();
			PlayerBean bean=new PlayerBean();
			bean.setPlayerName(request.getParameter("pname"));
			DateTimeFormatter dtf=DateTimeFormatter.ofPattern("dd/MM/yyyy");
			LocalDate date=LocalDate.parse(request.getParameter("dob"), dtf);
			bean.setDob(date);
			bean.setCountry(request.getParameter("team"));
			bean.setBattingStyle(request.getParameter("style"));
			bean.setCenturies(Integer.parseInt(request.getParameter("cnum")));
			bean.setMatches(Integer.parseInt(request.getParameter("match")));
			bean.setTotalRunScore(Integer.parseInt(request.getParameter("score")));
			
			boolean result=service.insertDetails(bean);
			if(result)
			{
				getServletContext().getRequestDispatcher(
						"/views/InsertSuccess.jsp").include(request, response);
			}
			else
			{

				request.setAttribute("error","Error in inserting");
				getServletContext().getRequestDispatcher(
						"/views/Error.jsp").include(request, response);
			}
		
		}
	}

}
