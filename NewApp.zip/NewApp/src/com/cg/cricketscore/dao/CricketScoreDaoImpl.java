package com.cg.cricketscore.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;

import com.cg.cricketscore.bean.PlayerBean;
import com.cg.cricketscore.util.DataBaseConnection;

public class CricketScoreDaoImpl implements ICricketScoreDao {

	@Override
	public ArrayList<PlayerBean> getDetails() {
		// TODO Auto-generated method stub
		ArrayList<PlayerBean> list=new ArrayList<>();

		try {
			Connection connection=DataBaseConnection.connection();
			PreparedStatement preparedStatement=connection.prepareStatement("select * from cricket_score");
			ResultSet resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				PlayerBean bean=new PlayerBean();
				bean.setPlayerId(resultSet.getInt(1));
				bean.setPlayerName(resultSet.getString(2));
				bean.setDob(resultSet.getDate(3).toLocalDate());
				LocalDate curDate=LocalDate.now();
				Period p=Period.between(bean.getDob(),curDate);
				bean.setAge(p.getYears());
				bean.setCountry(resultSet.getString(4));
				bean.setBattingStyle(resultSet.getString(5));
				bean.setCenturies(resultSet.getInt(6));
				bean.setMatches(resultSet.getInt(7));
				bean.setTotalRunScore(resultSet.getInt(8));
				list.add(bean);
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
