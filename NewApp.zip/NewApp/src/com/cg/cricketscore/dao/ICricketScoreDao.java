package com.cg.cricketscore.dao;

import java.util.ArrayList;

import com.cg.cricketscore.bean.PlayerBean;

public interface ICricketScoreDao {
	public ArrayList<PlayerBean> getDetails();

}
