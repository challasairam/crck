package com.cg.cricketscore.util;

import java.sql.Connection;

import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DataBaseConnection {
	private static Connection connection = null;
/**
 * Connection to database
 */
	public static Connection connection(){
		if (null == connection) {
			try {
				InitialContext icontext = new InitialContext();
				DataSource dataSource = (DataSource) icontext
						.lookup("java:/jdbc/OracleDS");
				connection = dataSource.getConnection();
			} catch (Exception e) {
			}
		}
		return connection;
	}
}
