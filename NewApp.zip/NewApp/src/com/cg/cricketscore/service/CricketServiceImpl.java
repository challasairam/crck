package com.cg.cricketscore.service;

import java.util.ArrayList;

import com.cg.cricketscore.bean.PlayerBean;
import com.cg.cricketscore.dao.CricketScoreDaoImpl;
import com.cg.cricketscore.dao.ICricketScoreDao;

public class CricketServiceImpl implements ICricketService {

	@Override
	public ArrayList<PlayerBean> getDetails() {
		ICricketScoreDao dao=new CricketScoreDaoImpl();
		return dao.getDetails();
	}

	@Override
	public boolean insertDetails(PlayerBean bean)
	{


		ICricketScoreDao dao=new CricketScoreDaoImpl();
		return dao.insertDetails(bean);
	}

}
