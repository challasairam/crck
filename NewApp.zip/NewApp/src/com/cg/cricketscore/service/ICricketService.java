package com.cg.cricketscore.service;

import java.util.ArrayList;

import com.cg.cricketscore.bean.PlayerBean;

public interface ICricketService {

	public ArrayList<PlayerBean> getDetails();

}
