package com.cg.cricketscore.bean;

import java.time.LocalDate;

public class PlayerBean {

	private Integer playerId;
	private String playerName;
	private LocalDate dob;
	private String country;
	private String battingStyle;
	private Integer centuries;
	private Integer matches;
	private Integer totalRunScore;
	private Integer age;
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public Integer getPlayerId() {
		return playerId;
	}
	public void setPlayerId(Integer playerId) {
		this.playerId = playerId;
	}
	public String getPlayerName() {
		return playerName;
	}
	public void setPlayerName(String playerName) {
		this.playerName = playerName;
	}
	public LocalDate getDob() {
		return dob;
	}
	public void setDob(LocalDate dob) {
		this.dob = dob;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getBattingStyle() {
		return battingStyle;
	}
	public void setBattingStyle(String battingStyle) {
		this.battingStyle = battingStyle;
	}
	public Integer getCenturies() {
		return centuries;
	}
	public void setCenturies(Integer centuries) {
		this.centuries = centuries;
	}
	public Integer getMatches() {
		return matches;
	}
	public void setMatches(Integer matches) {
		this.matches = matches;
	}
	public Integer getTotalRunScore() {
		return totalRunScore;
	}
	public void setTotalRunScore(Integer totalRunScore) {
		this.totalRunScore = totalRunScore;
	}
	public PlayerBean() {
		// TODO Auto-generated constructor stub
	}
	
}
